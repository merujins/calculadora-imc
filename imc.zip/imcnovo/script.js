function calculateIMC() {
    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;
    const sex = document.getElementById('sex').value;
    const height = parseFloat(document.getElementById('height').value);
    const weight = parseFloat(document.getElementById('weight').value);

    if (height > 0 && weight > 0) {
        const imc = (weight / (height * height)).toFixed(2);
        let imcCategory = '';
        let tips = '';

        if (imc < 18.5) {
            imcCategory = 'Abaixo do Peso';
            tips = 'Tente aumentar a ingestão de calorias com alimentos ricos em nutrientes.';
        } else if (imc >= 18.5 && imc < 24.9) {
            imcCategory = 'Peso Normal';
            tips = 'Parabéns! Mantenha uma alimentação equilibrada e atividades físicas.';
        } else if (imc >= 25 && imc < 29.9) {
            imcCategory = 'Sobrepeso';
            tips = 'Reduza alimentos processados e pratique mais atividades físicas.';
        } else if (imc >= 30 && imc < 34.9) {
            imcCategory = 'Obesidade Grau I';
            tips = 'Busque uma reeducação alimentar e aumente a atividade física.';
        } else {
            imcCategory = 'Obesidade Grau II';
            tips = 'Consulte um profissional de saúde para acompanhamento.';
        }

        const resultDiv = document.getElementById('result');
        resultDiv.innerHTML = `<p>${name}, seu IMC é ${imc} (${imcCategory}).</p><p>${tips}</p>`;
        resultDiv.style.opacity = 0;
        setTimeout(() => {
            resultDiv.style.opacity = 1;
        }, 100);
    } else {
        alert('Por favor, preencha os campos corretamente.');
    }
}

function clearFields() {
    document.getElementById('formIMC').reset();
    document.getElementById('result').innerHTML = '';
}

document.getElementById('print-btn').addEventListener('click', function() {
    window.print();
    clearFields(); // Limpar campos após a impressão
});

